import non_existent  # NOQA


def erroneous_view(request):
    pass
