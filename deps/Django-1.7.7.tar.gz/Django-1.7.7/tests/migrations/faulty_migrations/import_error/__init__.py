import fake_python_module  # NOQA
